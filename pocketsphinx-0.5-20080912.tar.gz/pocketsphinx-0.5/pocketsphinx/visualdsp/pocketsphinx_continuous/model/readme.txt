This is the place where you should copy necessary model files from pocketsphinx/model. After that run generate_model.py and you'll get model.c in CoreA directory.

Cheers,
Hannu / hkroger@gmail.com