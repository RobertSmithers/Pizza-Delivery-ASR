#include "main.h"

#include <services\services.h>				// system services
#include "../ezkitutilities.h"


// User program
void main() {

	int i=0;
	
	while(1) {
		idle();				//   do nothing
	}	// while(1)
		
	
}		// main



