=========================================================
VisualDSP++ port of Pocketsphinx for Blackfin 561 Ez-Lite 
=========================================================

To use visualdsp++ version of pocketsphinx, do the following:

1) Make sure you have "patch" in the system. 
2) Run copy_files.py
3) Add necessary files in model directory
4) Edit commandline parameters in command_line.h to use your models. 
5) Connect ez-lite serial port to your pc and open terminal to that port.
6) Build & run

Contact if you have any problems

Cheers,
Hannu Kr�ger (hkroger@gmail.com)